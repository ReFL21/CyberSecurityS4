# Scapy is a python packet design, manipulation, interceptor and processor.
# fast 
# comes with default values
# interactive 




# to see the layers in scapy 

from scapy.all import IP, ICMP, sr1, ls

ip_layer = IP(src="192.168.0.36", dst="www.dawn.com")



icmp_req = ICMP()





