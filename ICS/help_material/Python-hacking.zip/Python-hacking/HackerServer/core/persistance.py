def become_persistant(my_socket):
    print("[+] Become Persistant")
    
