# MAC_changer
 This program helps to change MAC address for your linux distro
 
 This program requires root privilages
 
 Runs on python 3.8 and above 
 
 sudo python3.8 main.py
 
